using System.Linq;
using System.Threading.Tasks;
using Viagem.Domain;
using Viagem.Persistence.Models;

namespace Viagem.Persistence.Contratos
{
    public interface IRotaPersist
    {
        Task<IQueryable<Rota>> GetAllRotasAsync();
        Task<Rota> GetRotaByIdAsync(int rotaId);
    }
}