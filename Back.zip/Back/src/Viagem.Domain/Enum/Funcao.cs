namespace Viagem.Domain.Enum
{
    public enum Funcao
    {
        NaoInformado,
        Participante,
        Palestrante
    }
}
