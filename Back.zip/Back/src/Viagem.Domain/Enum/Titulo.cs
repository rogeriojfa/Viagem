namespace Viagem.Domain.Enum
{
    public enum Titulo
    {
        NaoInformado,
        Tecnologo,
        Bacharel,
        Especialista,
        PosGraduado,
        Mestrado,
        Doutorado,
        PosDoutorado
    }
}
